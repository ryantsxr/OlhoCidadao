<?php
/**
 * Controla o número de tentativas de login por e-mail e aplica um bloqueio
 * temporário depois de várias tentativas seguidas incorretas.
 */
class LoginAttempt {
    private PDO $db;
    private const MAX_TENTATIVAS = 5;
    private const BLOQUEIO_SEGUNDOS = 300; // 5 minutos

    public function __construct() {
        $this->db = Database::getConnection();
    }

    /** Segundos restantes de bloqueio para este e-mail (0 = liberado). */
    public function segundosBloqueado(string $email): int {
        $stmt = $this->db->prepare('SELECT bloqueado_ate FROM login_attempts WHERE email = :email LIMIT 1');
        $stmt->execute(['email' => strtolower(trim($email))]);
        $ate = $stmt->fetchColumn();

        if (!$ate) {
            return 0;
        }
        $restante = strtotime($ate) - time();
        return $restante > 0 ? $restante : 0;
    }

    /** Registra uma tentativa incorreta e bloqueia o e-mail se passar do limite. */
    public function registrarFalha(string $email): void {
        $chave = strtolower(trim($email));

        $stmt = $this->db->prepare('SELECT tentativas FROM login_attempts WHERE email = :email LIMIT 1');
        $stmt->execute(['email' => $chave]);
        $tentativaAtual = $stmt->fetchColumn();
        $tentativas = ($tentativaAtual !== false ? (int) $tentativaAtual : 0) + 1;

        if ($tentativas >= self::MAX_TENTATIVAS) {
            $bloqueadoAte = date('Y-m-d H:i:s', time() + self::BLOQUEIO_SEGUNDOS);
            $upd = $this->db->prepare(
                'INSERT INTO login_attempts (email, tentativas, bloqueado_ate)
                 VALUES (:email, 0, :bloqueado)
                 ON DUPLICATE KEY UPDATE tentativas = 0, bloqueado_ate = :bloqueado2'
            );
            $upd->execute(['email' => $chave, 'bloqueado' => $bloqueadoAte, 'bloqueado2' => $bloqueadoAte]);
        } else {
            $upd = $this->db->prepare(
                'INSERT INTO login_attempts (email, tentativas)
                 VALUES (:email, :tentativas)
                 ON DUPLICATE KEY UPDATE tentativas = :tentativas2'
            );
            $upd->execute(['email' => $chave, 'tentativas' => $tentativas, 'tentativas2' => $tentativas]);
        }
    }

    /** Limpa o histórico de tentativas (chamar após um login bem-sucedido). */
    public function limpar(string $email): void {
        $stmt = $this->db->prepare('DELETE FROM login_attempts WHERE email = :email');
        $stmt->execute(['email' => strtolower(trim($email))]);
    }
}
