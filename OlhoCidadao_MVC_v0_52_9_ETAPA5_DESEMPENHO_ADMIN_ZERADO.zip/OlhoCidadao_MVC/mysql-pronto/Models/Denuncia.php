<?php
class Denuncia {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function create(
        int $userId,
        string $categoria,
        string $descricao,
        string $foto = '',
        ?float $latitude = null,
        ?float $longitude = null,
        string $endereco = ''
    ): array {
        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare(
                'INSERT INTO denuncias (usuario_id, categoria, descricao, foto, latitude, longitude, endereco, status)
                 VALUES (:usuario_id, :categoria, :descricao, :foto, :latitude, :longitude, :endereco, "Pendente")'
            );
            $stmt->execute([
                'usuario_id' => $userId,
                'categoria'  => $categoria,
                'descricao'  => $descricao,
                'foto'       => $foto,
                'latitude'   => $latitude,
                'longitude'  => $longitude,
                'endereco'   => $endereco,
            ]);

            $id = (int) $this->db->lastInsertId();
            $this->registrarHistorico($id, 'Pendente');
            $this->db->commit();
        } catch (Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }

        return $this->find($id);
    }

    private function registrarHistorico(int $denunciaId, string $status): void {
        $stmt = $this->db->prepare(
            'INSERT INTO denuncia_historico (denuncia_id, status) VALUES (:id, :status)'
        );
        $stmt->execute(['id' => $denunciaId, 'status' => $status]);
    }

    private function anexarHistorico(array $denuncia): array {
        $stmt = $this->db->prepare(
            'SELECT status, data FROM denuncia_historico WHERE denuncia_id = :id ORDER BY data ASC, id ASC'
        );
        $stmt->execute(['id' => $denuncia['id']]);
        $denuncia['historico'] = $stmt->fetchAll();
        return $denuncia;
    }

    public function byUser(int $userId): array {
        $stmt = $this->db->prepare('SELECT * FROM denuncias WHERE usuario_id = :id ORDER BY id ASC');
        $stmt->execute(['id' => $userId]);
        return array_map([$this, 'anexarHistorico'], $stmt->fetchAll());
    }

    /** Usada pelo painel do administrador: todas as denúncias do sistema. */
    public function todas(): array {
        $stmt = $this->db->query('SELECT * FROM denuncias ORDER BY id ASC');
        return array_map([$this, 'anexarHistorico'], $stmt->fetchAll());
    }

    public function find(int $id): ?array {
        $stmt = $this->db->prepare('SELECT * FROM denuncias WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        $denuncia = $stmt->fetch();
        return $denuncia ? $this->anexarHistorico($denuncia) : null;
    }

    /**
     * Cancela uma denúncia do próprio usuário.
     * Só é permitido enquanto o status ainda for "Pendente".
     */
    public function cancelar(int $id, int $userId): bool {
        $stmt = $this->db->prepare('SELECT usuario_id, status FROM denuncias WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        $denuncia = $stmt->fetch();

        if (!$denuncia || (int) $denuncia['usuario_id'] !== $userId) {
            return false; // não é dono da denúncia
        }
        if (strtolower($denuncia['status']) !== 'pendente') {
            return false; // só pode cancelar enquanto pendente
        }

        $upd = $this->db->prepare('UPDATE denuncias SET status = "Cancelada" WHERE id = :id');
        $upd->execute(['id' => $id]);
        $this->registrarHistorico($id, 'Cancelada');

        return true;
    }

    /** Usada pelo painel do administrador para mudar o status de uma denúncia. */
    public function atualizarStatus(int $id, string $status): bool {
        $validos = ['Pendente', 'Em análise', 'Resolvido'];
        if (!in_array($status, $validos, true)) {
            return false;
        }

        $stmt = $this->db->prepare('SELECT status FROM denuncias WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        $atual = $stmt->fetchColumn();
        if ($atual === false) {
            return false;
        }

        $upd = $this->db->prepare('UPDATE denuncias SET status = :status WHERE id = :id');
        $upd->execute(['status' => $status, 'id' => $id]);

        if ($atual !== $status) {
            $this->registrarHistorico($id, $status);
        }

        return true;
    }
}
