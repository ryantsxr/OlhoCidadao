<?php
class User {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function findByEmail(string $email): ?array {
        $stmt = $this->db->prepare('SELECT * FROM users WHERE LOWER(email) = LOWER(:email) LIMIT 1');
        $stmt->execute(['email' => trim($email)]);
        $user = $stmt->fetch();
        return $user ?: null;
    }

    public function find(int $id): ?array {
        $stmt = $this->db->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        $user = $stmt->fetch();
        return $user ?: null;
    }

    public function create(array $data): array {
        $stmt = $this->db->prepare(
            'INSERT INTO users (nome, email, senha, cidade, telefone, cpf, cep, foto, role)
             VALUES (:nome, :email, :senha, :cidade, :telefone, :cpf, :cep, :foto, :role)'
        );
        $stmt->execute([
            'nome'     => trim($data['nome']),
            'email'    => trim($data['email']),
            'senha'    => password_hash($data['senha'], PASSWORD_DEFAULT),
            'cidade'   => $data['cidade'] ?? '',
            'telefone' => $data['telefone'] ?? '',
            'cpf'      => $data['cpf'] ?? '',
            'cep'      => $data['cep'] ?? '',
            'foto'     => $data['foto'] ?? '',
            'role'     => $data['role'] ?? 'cidadao',
        ]);

        return $this->find((int) $this->db->lastInsertId());
    }

    public function update(int $id, array $data): ?array {
        $campos = [];
        $params = ['id' => $id];

        foreach (['nome', 'email', 'cidade', 'telefone', 'cpf', 'cep', 'foto'] as $campo) {
            if (array_key_exists($campo, $data)) {
                $campos[] = "$campo = :$campo";
                $params[$campo] = $data[$campo];
            }
        }
        if (!empty($data['senha'])) {
            $campos[] = 'senha = :senha';
            $params['senha'] = password_hash($data['senha'], PASSWORD_DEFAULT);
        }
        if (!$campos) {
            return $this->find($id);
        }

        $sql = 'UPDATE users SET ' . implode(', ', $campos) . ' WHERE id = :id';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return $this->find($id);
    }

    /** Verifica se outra conta (id diferente de $excetoId) já usa esse e-mail. */
    public function emailEmUsoPorOutro(string $email, int $excetoId): bool {
        $stmt = $this->db->prepare(
            'SELECT id FROM users WHERE LOWER(email) = LOWER(:email) AND id != :id LIMIT 1'
        );
        $stmt->execute(['email' => trim($email), 'id' => $excetoId]);
        return (bool) $stmt->fetch();
    }

    /** Verifica se outra conta (id diferente de $excetoId) já usa esse CPF (só dígitos). */
    public function cpfEmUsoPorOutro(string $cpf, int $excetoId): bool {
        $cpf = preg_replace('/\D+/', '', $cpf) ?? '';
        if ($cpf === '') return false;
        $stmt = $this->db->prepare(
            'SELECT id FROM users WHERE cpf = :cpf AND id != :id LIMIT 1'
        );
        $stmt->execute(['cpf' => $cpf, 'id' => $excetoId]);
        return (bool) $stmt->fetch();
    }
}
