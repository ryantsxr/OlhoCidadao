# Ativar o MySQL (quando quiser)

Estes 3 arquivos são as versões dos Models que já falam com MySQL em vez de JSON.
Por enquanto o projeto está rodando com os arquivos JSON (em `storage/`), então
estes aqui estão só guardados, esperando.

Quando você quiser ativar:

1. Importe `sql/schema.sql` no phpMyAdmin (cria o banco `olho_cidadao`).
2. Confira as credenciais em `app/config.php` (usuário/senha do MySQL).
3. Rode `php tools/migrar_json_para_mysql.php` uma vez, pra copiar os dados que
   já existem em `storage/users.json` e `storage/denuncias.json` para o banco.
4. Copie os 3 arquivos desta pasta (`User.php`, `Denuncia.php`, `LoginAttempt.php`)
   para dentro de `app/Models/`, substituindo os que estão lá.
5. Abra `public/index.php` e adicione esta linha logo depois de `session_start();`:

   require __DIR__ . '/../app/config.php';

6. Pronto — teste o login e uma denúncia nova pra confirmar que está tudo
   gravando no banco.

> ATENÇÃO: estes Models estão desatualizados em relação a `app/Models/` (faltam apoios, protocolo, reabertura,
> avaliação, notificações etc.). Atualize-os antes de ativar o MySQL.
