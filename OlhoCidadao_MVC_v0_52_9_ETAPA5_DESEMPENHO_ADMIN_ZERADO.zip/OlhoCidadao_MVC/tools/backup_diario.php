<?php
/** Executar: php tools/backup_diario.php (ou agendar cron/tarefa do Windows). */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
require_once __DIR__ . '/../app/config.php';
spl_autoload_register(static function ($class) {
    foreach (['Core', 'Models'] as $dir) {
        $arq = __DIR__ . '/../app/' . $dir . '/' . $class . '.php';
        if (is_file($arq)) { require_once $arq; return; }
    }
});
try {
    $migrados = PrivacidadeCpf::migrarExistentes();
    $novo = BackupDiario::executar();
    echo 'CPF(s) migrados: ' . $migrados . '; backup ' . ($novo ? 'criado' : 'já existente') . PHP_EOL;
} catch (Throwable $e) {
    error_log((string)$e);
    fwrite(STDERR, 'Erro no backup/migração. Consulte o log do PHP.' . PHP_EOL);
    exit(1);
}
