<?php
/** Use no terminal: php tools/verificar_instalacao.php */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
require_once __DIR__ . '/../app/config.php';
$problemas = 0;
function verificar(bool $ok, string $rotulo): void {
    global $problemas;
    echo ($ok ? '[OK] ' : '[ATENÇÃO] ') . $rotulo . PHP_EOL;
    if (!$ok) $problemas++;
}
verificar(PHP_VERSION_ID >= 80100, 'PHP 8.1+');
foreach (['openssl','fileinfo','json'] as $ext) verificar(extension_loaded($ext), 'Extensão ' . $ext);
echo extension_loaded('gd')
    ? '[OK] Extensão GD (remove metadados EXIF das fotos)' . PHP_EOL
    : '[RECOMENDADO] Ative GD para remover metadados EXIF. Sem GD, o envio funciona e as fotos permanecem privadas, mas mantêm os metadados originais.' . PHP_EOL;
$dir = dirname(__DIR__) . '/storage';
verificar(is_dir($dir) && is_writable($dir), 'storage/ gravável');
verificar(is_dir($dir . '/uploads') && is_writable($dir . '/uploads'), 'storage/uploads gravável');
verificar(is_dir(dirname(__DIR__) . '/public/img'), 'Arquivos públicos presentes');
$usuarios = json_decode((string)@file_get_contents($dir . '/users.json'), true);
verificar(is_array($usuarios), 'JSON de usuários legível');
if (is_array($usuarios)) {
    $admins = array_values(array_filter($usuarios, fn($u)=>($u['role']??'') === 'admin'));
    verificar(count($admins)>0, 'Pelo menos 1 administrador');
}
verificar(APP_URL !== '', 'APP_URL configurada (necessária para e-mails com URL correta)');
verificar(SMTP_HOST !== '', 'SMTP configurado para notificações e redefinição de senha');
verificar(LGPD_CONTATO !== '', 'Contato de privacidade definido');
echo PHP_EOL . "IMPORTANTE: HTTPS, permissões Apache, domínio e restaurar backups exigem testes na hospedagem." . PHP_EOL;
exit($problemas ? 1 : 0);
