<?php
/**
 * Copia os dados que estão hoje em storage/*.json para o MySQL.
 *
 * RODE ISSO UMA ÚNICA VEZ, depois de importar sql/schema.sql no phpMyAdmin.
 * Como rodar:
 *   - Pelo terminal:  php tools/migrar_json_para_mysql.php
 *   - Ou pelo navegador, acessando este arquivo diretamente (se ele estiver
 *     em uma pasta acessível pelo navegador — depois apague o arquivo).
 *
 * Rodar mais de uma vez não duplica nada (usa ON DUPLICATE KEY UPDATE),
 * mas o ideal é rodar só uma vez e depois arquivar/apagar este script.
 */

require __DIR__ . '/../app/config.php';
require __DIR__ . '/../app/Core/Database.php';

$db = Database::getConnection();

// ---------------------------------------------------------------------
// Usuários
// ---------------------------------------------------------------------
$usersFile = __DIR__ . '/../storage/users.json';
$users = json_decode(file_get_contents($usersFile), true) ?: [];

$stmtUser = $db->prepare(
    'INSERT INTO users (id, nome, email, senha, cidade, telefone, foto, role)
     VALUES (:id, :nome, :email, :senha, :cidade, :telefone, :foto, :role)
     ON DUPLICATE KEY UPDATE nome = VALUES(nome)'
);
foreach ($users as $u) {
    $stmtUser->execute([
        'id'       => $u['id'],
        'nome'     => $u['nome'],
        'email'    => $u['email'],
        'senha'    => $u['senha'], // já é um hash pronto, copia direto
        'cidade'   => $u['cidade'] ?? '',
        'telefone' => $u['telefone'] ?? '',
        'foto'     => $u['foto'] ?? '',
        'role'     => $u['role'] ?? 'cidadao',
    ]);
}
echo count($users) . " usuário(s) migrados.\n";

// ---------------------------------------------------------------------
// Denúncias + histórico
// ---------------------------------------------------------------------
$denunciasFile = __DIR__ . '/../storage/denuncias.json';
$denuncias = json_decode(file_get_contents($denunciasFile), true) ?: [];

$stmtDen = $db->prepare(
    'INSERT INTO denuncias (id, usuario_id, categoria, descricao, foto, latitude, longitude, endereco, status, criada_em)
     VALUES (:id, :usuario_id, :categoria, :descricao, :foto, :latitude, :longitude, :endereco, :status, :criada_em)
     ON DUPLICATE KEY UPDATE status = VALUES(status)'
);
$stmtHist = $db->prepare(
    'INSERT INTO denuncia_historico (denuncia_id, status, data) VALUES (:id, :status, :data)'
);

foreach ($denuncias as $d) {
    $stmtDen->execute([
        'id'         => $d['id'],
        'usuario_id' => $d['usuario_id'],
        'categoria'  => $d['categoria'],
        'descricao'  => $d['descricao'],
        'foto'       => $d['foto'] ?? '',
        'latitude'   => $d['latitude'] ?? null,
        'longitude'  => $d['longitude'] ?? null,
        'endereco'   => $d['endereco'] ?? '',
        'status'     => $d['status'],
        'criada_em'  => $d['criada_em'],
    ]);

    foreach (($d['historico'] ?? []) as $h) {
        $stmtHist->execute([
            'id'     => $d['id'],
            'status' => $h['status'],
            'data'   => $h['data'],
        ]);
    }
}
echo count($denuncias) . " denúncia(s) migradas.\n";

// ---------------------------------------------------------------------
// Ajusta o AUTO_INCREMENT para não colidir com os IDs que acabaram de ser
// importados (senão o próximo cadastro/denúncia pode tentar usar um ID
// que já existe).
// ---------------------------------------------------------------------
$proxUser = (int) $db->query('SELECT COALESCE(MAX(id), 0) FROM users')->fetchColumn() + 1;
$db->exec('ALTER TABLE users AUTO_INCREMENT = ' . $proxUser);

$proxDenuncia = (int) $db->query('SELECT COALESCE(MAX(id), 0) FROM denuncias')->fetchColumn() + 1;
$db->exec('ALTER TABLE denuncias AUTO_INCREMENT = ' . $proxDenuncia);

echo "Migração concluída.\n";
