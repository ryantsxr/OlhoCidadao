<?php
/** Uso: php tools/verificar_backup.php 2026-10-08 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
$data = $argv[1] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/D', $data)) { fwrite(STDERR, "Data inválida.\n"); exit(1); }
$raiz = __DIR__ . '/../storage/backups/' . $data;
$m = json_decode((string)@file_get_contents($raiz . '/manifesto.json'), true);
if (!is_array($m) || empty($m['arquivos'])) { fwrite(STDERR,"Backup inexistente ou incompleto.\n"); exit(1); }
$validos = 0;
foreach ($m['arquivos'] as $nome=>$hash) {
    if (!preg_match('#^(?:uploads/)?[a-zA-Z0-9_.-]+$#D',$nome) || str_contains($nome, '..') || !is_file($raiz . '/' . $nome) || !hash_equals($hash, hash_file('sha256',$raiz . '/' . $nome))) {
        fwrite(STDERR, "ERRO: Arquivo de backup ausente ou alterado: $nome\n"); exit(1);
    }
    $validos++;
}
echo "Backup $data: $validos arquivos verificados por SHA-256.\n";
