// ===============================
// DICIONÁRIO DE TRADUÇÕES GLOBAL
// ===============================
const traducoes = {
    "pt-br": {
        "inicio": "Início",
        "config": "Configurações",
        "minhas-denuncias": "Minhas denúncias",
        "titulo-config": "Configurações",
        "sub-config": "Personalize a sua experiência no aplicativo.",
        "tema-escuro": "Tema Escuro",
        "idioma": "Idioma",
        "tamanho-fonte": "Tamanho da Fonte",
        "contraste": "Alto Contraste",
        "salvar": "Salvar Alterações",
        "perfil": "Perfil",
        "sair": "Sair",
        "ola": "Olá,",
        "bem-vindo": "Bem-vindo ao Olho Cidadão",
        "fazer-denuncia": "Fazer denúncia",
        "denuncias-feitas": "Denúncias feitas",
        "em-analise": "Em análise",
        "resolvidas": "Resolvidas",
        "categorias": "Categorias",
        "iluminacao": "Iluminação",
        "sinalizacao": "Sinalização",
        "lixo": "Lixo",
        "outros": "Outros",
        "denuncias-recentes": "Denúncias recentes",
        "pendente": "Pendente",
        "resolvido": "Resolvido",
        "cidadao": "Cidadão",
        "desc-tema": "Altera a aparência geral do sistema",
        "desc-idioma": "Selecione o idioma de sua preferência",
        "desc-fonte": "Aumente ou diminua o tamanho dos textos",
        "desc-contraste": "Melhora a leitura para pessoas com baixa visão",
        "opcao-padrao": "Padrão",
        "opcao-grande": "Grande (+20%)",
        "opcao-extra-grande": "Extra Grande (+40%)",
        "opcao-pt": "Português (BR)",
        "opcao-en": "English (US)",
        "opcao-es": "Español",
        "meu-perfil": "Meu Perfil",
        "gerenciar-info": "Gerencie suas informações e segurança",
        "toque-foto": "Toque na câmera para alterar a foto",
        "nome-completo": "Nome Completo",
        "email": "E-mail",
        "cidade": "Cidade",
        "telefone": "Telefone",
        "alterar-senha": "Alterar Senha",
        "nova-senha": "Nova Senha",
        "confirmar-nova-senha": "Confirmar Nova Senha",
        "placeholder-nome": "Ex: Eric Valiante",
        "placeholder-email": "exemplo@email.com",
        "placeholder-cidade": "Sua cidade",
        "placeholder-tel": "(00) 00000-0000",
        "placeholder-nova-senha": "Deixe em branco para não alterar",
        "placeholder-confirma-senha": "Confirme a nova senha"
    },
    "en": {
        "inicio": "Home",
        "config": "Settings",
        "minhas-denuncias": "My Reports",
        "titulo-config": "Settings",
        "sub-config": "Customize your app experience.",
        "tema-escuro": "Dark Theme",
        "idioma": "Language",
        "tamanho-fonte": "Font Size",
        "contraste": "High Contrast",
        "salvar": "Save Changes",
        "perfil": "Profile",
        "sair": "Log out",
        "ola": "Hello,",
        "bem-vindo": "Welcome to Olho Cidadão",
        "fazer-denuncia": "Report an issue",
        "denuncias-feitas": "Reports made",
        "em-analise": "Under review",
        "resolvidas": "Resolved",
        "categorias": "Categories",
        "iluminacao": "Lighting",
        "sinalizacao": "Traffic signs",
        "lixo": "Trash",
        "outros": "Others",
        "denuncias-recentes": "Recent reports",
        "pendente": "Pending",
        "resolvido": "Resolved",
        "cidadao": "Citizen",
        "desc-tema": "Changes the overall appearance of the system",
        "desc-idioma": "Select your preferred language",
        "desc-fonte": "Increase or decrease the text size",
        "desc-contraste": "Improves readability for people with low vision",
        "opcao-padrao": "Default",
        "opcao-grande": "Large (+20%)",
        "opcao-extra-grande": "Extra Large (+40%)",
        "opcao-pt": "Portuguese (BR)",
        "opcao-en": "English (US)",
        "opcao-es": "Spanish",
        "meu-perfil": "My Profile",
        "gerenciar-info": "Manage your information and security",
        "toque-foto": "Tap the camera icon to change your photo",
        "nome-completo": "Full Name",
        "email": "Email",
        "cidade": "City",
        "telefone": "Phone",
        "alterar-senha": "Change Password",
        "nova-senha": "New Password",
        "confirmar-nova-senha": "Confirm New Password",
        "placeholder-nome": "e.g. Eric Valiante",
        "placeholder-email": "example@email.com",
        "placeholder-cidade": "Your city",
        "placeholder-tel": "(00) 00000-0000",
        "placeholder-nova-senha": "Leave blank to keep the current password",
        "placeholder-confirma-senha": "Confirm the new password"
    },
    "es": {
        "inicio": "Inicio",
        "config": "Configuraciones",
        "minhas-denuncias": "Mis denuncias",
        "titulo-config": "Configuración",
        "sub-config": "Personaliza tu experiencia en la aplicación.",
        "tema-escuro": "Tema Oscuro",
        "idioma": "Idioma",
        "tamanho-fonte": "Tamaño de Fuente",
        "contraste": "Alto Contraste",
        "salvar": "Guardar Cambios",
        "perfil": "Perfil",
        "sair": "Salir",
        "ola": "Hola,",
        "bem-vindo": "Bienvenido a Olho Cidadão",
        "fazer-denuncia": "Hacer denuncia",
        "denuncias-feitas": "Denuncias realizadas",
        "em-analise": "En análisis",
        "resolvidas": "Resueltas",
        "categorias": "Categorías",
        "iluminacao": "Iluminación",
        "sinalizacao": "Señalización",
        "lixo": "Basura",
        "outros": "Otros",
        "denuncias-recentes": "Denuncias recientes",
        "pendente": "Pendiente",
        "resolvido": "Resuelto",
        "cidadao": "Ciudadano",
        "desc-tema": "Cambia la apariencia general del sistema",
        "desc-idioma": "Selecciona tu idioma preferido",
        "desc-fonte": "Aumenta o disminuye el tamaño de los textos",
        "desc-contraste": "Mejora la lectura para personas con baja visión",
        "opcao-padrao": "Predeterminado",
        "opcao-grande": "Grande (+20%)",
        "opcao-extra-grande": "Extra Grande (+40%)",
        "opcao-pt": "Portugués (BR)",
        "opcao-en": "Inglés (US)",
        "opcao-es": "Español",
        "meu-perfil": "Mi Perfil",
        "gerenciar-info": "Gestiona tu información y seguridad",
        "toque-foto": "Toca la cámara para cambiar la foto",
        "nome-completo": "Nombre Completo",
        "email": "Correo electrónico",
        "cidade": "Ciudad",
        "telefone": "Teléfono",
        "alterar-senha": "Cambiar Contraseña",
        "nova-senha": "Nueva Contraseña",
        "confirmar-nova-senha": "Confirmar Nueva Contraseña",
        "placeholder-nome": "Ej: Eric Valiante",
        "placeholder-email": "ejemplo@email.com",
        "placeholder-cidade": "Tu ciudad",
        "placeholder-tel": "(00) 00000-0000",
        "placeholder-nova-senha": "Deja en blanco para no cambiarla",
        "placeholder-confirma-senha": "Confirma la nueva contraseña"
    }
};

document.addEventListener("DOMContentLoaded", () => {
    carregarPreferenciasGlobais();

    const btnSalvar = document.querySelector('.btn-salvar');
    const form = btnSalvar ? btnSalvar.closest('form') : null;

    if (window.CONFIG_SERVIDOR) {
        localStorage.setItem('configOlhoCidadao', JSON.stringify(window.CONFIG_SERVIDOR));
        preencherFormularioConfiguracoes(window.CONFIG_SERVIDOR);
        aplicarConfiguracaoVisual(window.CONFIG_SERVIDOR);
    }

    if (form) {
        form.addEventListener('submit', () => {
            localStorage.setItem('configOlhoCidadao', JSON.stringify(obterConfiguracaoFormulario()));
        });
    }

    const selectIdioma = document.getElementById('select-idioma');
    if (selectIdioma) {
        selectIdioma.addEventListener('change', () => aplicarIdioma(selectIdioma.value));
    }
});

// ===============================
// FUNÇÕES DE APLICAÇÃO
function aplicarTamanhoFonte(tamanho) {
    if (tamanho === 'grande') {
        document.documentElement.style.fontSize = '120%';
    } else if (tamanho === 'extra-grande') {
        document.documentElement.style.fontSize = '140%';
    } else {
        document.documentElement.style.fontSize = '100%';
    }
}

/**
 * Aplica o idioma escolhido em TODOS os elementos da página que tiverem
 * o atributo data-i18n="<chave>". Assim, qualquer texto novo do site só
 * precisa desse atributo no HTML — não é preciso mexer no JS de novo.
 *
 * Exemplos de uso no HTML:
 *   <span id="texto-inicio" data-i18n="inicio"></span>
 *   <h1 data-i18n="titulo-config"></h1>
 *   <p data-i18n="sub-config"></p>
 *   <label data-i18n="tema-escuro"></label>
 *
 * Para inputs/placeholders, use data-i18n-placeholder="<chave>".
 * Para atributos title, use data-i18n-title="<chave>".
 */
function aplicarIdioma(siglaIdioma) {
    const t = traducoes[siglaIdioma];
    if (!t) return;

    // Atualiza o texto interno de qualquer elemento marcado com data-i18n
    document.querySelectorAll('[data-i18n]').forEach((el) => {
        const chave = el.getAttribute('data-i18n');
        if (t[chave] !== undefined) {
            el.innerText = t[chave];
        }
    });

    // Atualiza placeholders (ex: campos de busca/formulário)
    document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
        const chave = el.getAttribute('data-i18n-placeholder');
        if (t[chave] !== undefined) {
            el.setAttribute('placeholder', t[chave]);
        }
    });

    // Atualiza atributos title (tooltips)
    document.querySelectorAll('[data-i18n-title]').forEach((el) => {
        const chave = el.getAttribute('data-i18n-title');
        if (t[chave] !== undefined) {
            el.setAttribute('title', t[chave]);
        }
    });

    // Mantém compatibilidade com os IDs antigos, caso o data-i18n
    // ainda não tenha sido adicionado em algum HTML.
    const mapaIdsAntigos = {
        'texto-inicio': 'inicio',
        'texto-config': 'config',
        'titulo-principal-config': 'titulo-config'
    };
    Object.entries(mapaIdsAntigos).forEach(([id, chave]) => {
        const el = document.getElementById(id);
        if (el && t[chave] !== undefined) {
            el.innerText = t[chave];
        }
    });

    // Marca o idioma atual no <html> (útil para CSS/acessibilidade)
    document.documentElement.setAttribute('lang', siglaIdioma);
}

function obterConfiguracaoFormulario() {
    return {
        temaEscuro: document.getElementById('toggle-tema')?.checked ?? true,
        idioma: document.getElementById('select-idioma')?.value ?? 'pt-br',
        fonte: document.getElementById('select-fonte')?.value ?? 'padrao',
        altoContraste: document.getElementById('toggle-contraste')?.checked ?? false,
        modoDaltonico: document.getElementById('toggle-daltonico')?.checked ?? false,
        fonteLeitura: document.getElementById('toggle-leitura')?.checked ?? false
    };
}

function salvarConfiguracoes() {
    const config = obterConfiguracaoFormulario();
    localStorage.setItem('configOlhoCidadao', JSON.stringify(config));
    aplicarConfiguracaoVisual(config);
}

function aplicarConfiguracaoVisual(config) {
    aplicarTamanhoFonte(config.fonte);

    if (config.temaEscuro === false) {
        document.body.classList.add('tema-claro');
    } else {
        document.body.classList.remove('tema-claro');
    }

    document.body.classList.toggle('alto-contraste', config.altoContraste === true);
    document.body.classList.toggle('modo-daltonico', config.modoDaltonico === true);
    document.documentElement.classList.toggle('pre-modo-daltonico', config.modoDaltonico === true);
    document.body.classList.toggle('fonte-leitura', config.fonteLeitura === true);

    if (config.idioma) aplicarIdioma(config.idioma);
}

function carregarPreferenciasGlobais() {
    let config = window.CONFIG_SERVIDOR || null;

    if (!config) {
        const configSalva = localStorage.getItem('configOlhoCidadao');
        if (configSalva) {
            try {
                config = JSON.parse(configSalva);
            } catch (e) {
                localStorage.removeItem('configOlhoCidadao');
            }
        }
    }

    if (config) aplicarConfiguracaoVisual(config);
}

function preencherFormularioConfiguracoes(config = null) {
    if (!config) {
        const configSalva = localStorage.getItem('configOlhoCidadao');
        if (!configSalva) return;
        try {
            config = JSON.parse(configSalva);
        } catch (e) {
            return;
        }
    }

    const tTema = document.getElementById('toggle-tema');
    const sIdioma = document.getElementById('select-idioma');
    const sFonte = document.getElementById('select-fonte');
    const tContraste = document.getElementById('toggle-contraste');

    if (tTema) tTema.checked = config.temaEscuro === true;
    if (sIdioma) sIdioma.value = config.idioma || 'pt-br';
    if (sFonte) sFonte.value = config.fonte || 'padrao';
    if (tContraste) tContraste.checked = config.altoContraste === true;
    const tDalt = document.getElementById('toggle-daltonico');
    const tLeit = document.getElementById('toggle-leitura');
    if (tDalt) tDalt.checked = config.modoDaltonico === true;
    if (tLeit) tLeit.checked = config.fonteLeitura === true;
}

// ===============================
// NOTIFICAÇÕES (TOAST)
// ===============================
function mostrarToast(mensagem, tipo = 'erro') {
    if (!mensagem) return;

    if (!document.getElementById('estilo-toast')) {
        const estilo = document.createElement('style');
        estilo.id = 'estilo-toast';
        estilo.textContent = `
            .toast-container {
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 9999;
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            .toast {
                min-width: 260px;
                max-width: 360px;
                padding: 14px 18px;
                border-radius: 10px;
                font-family: Poppins, sans-serif;
                font-size: 14px;
                line-height: 1.4;
                box-shadow: 0 8px 20px rgba(0,0,0,0.35);
                display: flex;
                align-items: flex-start;
                gap: 10px;
                animation: toast-entrar 0.3s ease-out;
            }
            .toast.erro { background: #3a1f24; border: 1px solid #ff5050; color: #ff9b9b; }
            .toast.sucesso { background: #1f3a22; border: 1px solid #6B8E4E; color: #B7CFA1; }
            .toast i { margin-top: 2px; }
            .toast.saindo { animation: toast-saida 0.3s ease-in forwards; }
            @keyframes toast-entrar {
                from { transform: translateX(120%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes toast-saida {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(120%); opacity: 0; }
            }
            @media (max-width: 480px) {
                .toast-container { left: 16px; right: 16px; top: 16px; }
                .toast { max-width: none; }
            }
        `;
        document.head.appendChild(estilo);
    }

    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = 'toast ' + (tipo === 'sucesso' ? 'sucesso' : 'erro');

    const icone = document.createElement('i');
    icone.className = 'fa-solid ' + (tipo === 'sucesso' ? 'fa-circle-check' : 'fa-circle-exclamation');

    const texto = document.createElement('span');
    texto.textContent = mensagem;

    toast.appendChild(icone);
    toast.appendChild(texto);
    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('saindo');
        setTimeout(() => toast.remove(), 300);
    }, 4500);
}
