-- Olho Cidadão — schema MySQL
-- Como usar: no phpMyAdmin, aba "SQL" (sem selecionar nenhum banco antes),
-- cole este arquivo inteiro e clique em "Executar". Ele cria o banco e as tabelas.

CREATE DATABASE IF NOT EXISTS olho_cidadao
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE olho_cidadao;

-- ---------------------------------------------------------------------
-- Usuários (cidadãos e admins)
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome       VARCHAR(150) NOT NULL,
  email      VARCHAR(190) NOT NULL,
  senha      VARCHAR(255) NOT NULL,
  cidade     VARCHAR(150) NOT NULL DEFAULT '',
  telefone   VARCHAR(30)  NOT NULL DEFAULT '',
  cpf        VARCHAR(11)  NOT NULL DEFAULT '',
  cep        VARCHAR(8)   NOT NULL DEFAULT '',
  foto       VARCHAR(255) NOT NULL DEFAULT '',
  role       ENUM('cidadao','admin') NOT NULL DEFAULT 'cidadao',
  criado_em  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Denúncias
-- ---------------------------------------------------------------------
CREATE TABLE denuncias (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id  INT UNSIGNED NOT NULL,
  categoria   ENUM('iluminacao','sinalizacao','lixo','outros') NOT NULL,
  descricao   TEXT NOT NULL,
  foto        VARCHAR(255) NOT NULL DEFAULT '',
  latitude    DECIMAL(10,7) NULL,
  longitude   DECIMAL(10,7) NULL,
  endereco    VARCHAR(255) NOT NULL DEFAULT '',
  status      ENUM('Pendente','Em análise','Resolvido','Cancelada') NOT NULL DEFAULT 'Pendente',
  criada_em   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_denuncias_usuario FOREIGN KEY (usuario_id)
    REFERENCES users(id) ON DELETE CASCADE,
  KEY idx_denuncias_usuario (usuario_id),
  KEY idx_denuncias_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Linha do tempo de cada denúncia (histórico de status)
-- ---------------------------------------------------------------------
CREATE TABLE denuncia_historico (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  denuncia_id  INT UNSIGNED NOT NULL,
  status       VARCHAR(30) NOT NULL,
  data         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_historico_denuncia FOREIGN KEY (denuncia_id)
    REFERENCES denuncias(id) ON DELETE CASCADE,
  KEY idx_historico_denuncia (denuncia_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Controle de tentativas de login (bloqueio por força bruta)
-- ---------------------------------------------------------------------
CREATE TABLE login_attempts (
  email          VARCHAR(190) NOT NULL PRIMARY KEY,
  tentativas     INT UNSIGNED NOT NULL DEFAULT 0,
  bloqueado_ate  DATETIME NULL
) ENGINE=InnoDB;
