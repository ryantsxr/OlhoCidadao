<?php
/**
 * Rate limit genérico por IP, reutilizável em qualquer ação sensível a abuso
 * (cadastro, pedido de redefinição de senha, etc.) — mesma ideia do
 * LoginAttempt, só que parametrizável em vez de fixa para o login.
 *
 * Uso:
 *   $limiter = new RateLimiter('cadastro', maxTentativas: 8, bloqueioSegundos: 600);
 *   if ($limiter->bloqueado() > 0) { ...avisa e redireciona... }
 *   $limiter->registrarTentativa();
 */
class RateLimiter {
    private string $file;
    private string $acao;
    private int $maxTentativas;
    private int $bloqueioSegundos;

    public function __construct(string $acao, int $maxTentativas = 5, int $bloqueioSegundos = 300) {
        $this->acao = $acao;
        $this->maxTentativas = $maxTentativas;
        $this->bloqueioSegundos = $bloqueioSegundos;
        $this->file = __DIR__ . '/../../storage/rate_limits.json';
        if (!file_exists($this->file)) {
            file_put_contents($this->file, '{}', LOCK_EX);
        }
    }

    private function all(): array {
        return LeituraJson::array($this->file);
    }

    private function saveAll(array $data): void {
        GravacaoSegura::json($this->file, $data);
    }

    /** Identifica quem está tentando: ação + IP (independe do e-mail digitado). */
    private function chave(): string {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        return $this->acao . ':' . $ip;
    }

    /** Segundos restantes de bloqueio pra essa ação+IP (0 = liberado). */
    public function bloqueado(): int {
        $data = $this->all();
        $chave = $this->chave();
        if (empty($data[$chave]['bloqueado_ate'])) {
            return 0;
        }
        $restante = $data[$chave]['bloqueado_ate'] - time();
        return $restante > 0 ? $restante : 0;
    }

    /** Registra mais uma tentativa e bloqueia se passar do limite. */
    public function registrarTentativa(): void {
        ArquivoLock::executar('rate_limits', function () {
            $data = $this->all();
            $chave = $this->chave();

            $tentativas = ($data[$chave]['tentativas'] ?? 0) + 1;

            if ($tentativas >= $this->maxTentativas) {
                $data[$chave] = [
                    'tentativas' => 0,
                    'bloqueado_ate' => time() + $this->bloqueioSegundos,
                ];
            } else {
                $data[$chave]['tentativas'] = $tentativas;
            }

            $this->saveAll($data);
        });
    }

    /** Limpa o histórico dessa ação+IP (chamar depois de uma tentativa legítima bem-sucedida). */
    public function limpar(): void {
        ArquivoLock::executar('rate_limits', function () {
            $data = $this->all();
            unset($data[$this->chave()]);
            $this->saveAll($data);
        });
    }
}
