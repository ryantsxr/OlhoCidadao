<?php
/**
 * Controla o número de tentativas de login por e-mail e aplica um bloqueio
 * temporário depois de várias tentativas seguidas incorretas.
 */
class LoginAttempt {
    private string $file;
    private const MAX_TENTATIVAS = 5;
    private const BLOQUEIO_SEGUNDOS = 300; // 5 minutos

    public function __construct() {
        $this->file = __DIR__ . '/../../storage/login_attempts.json';
        if (!file_exists($this->file)) {
            file_put_contents($this->file, '{}', LOCK_EX);
        }
    }

    private function all(): array {
        return LeituraJson::array($this->file);
    }

    private function saveAll(array $data): void {
        GravacaoSegura::json($this->file, $data);
    }

    /** Segundos restantes de bloqueio para este e-mail (0 = liberado). */
    public function segundosBloqueado(string $email): int {
        $data = $this->all();
        $chave = strtolower(trim($email));
        if (empty($data[$chave]['bloqueado_ate'])) {
            return 0;
        }
        $restante = $data[$chave]['bloqueado_ate'] - time();
        return $restante > 0 ? $restante : 0;
    }

    /** Registra uma tentativa incorreta e bloqueia o e-mail se passar do limite. */
    public function registrarFalha(string $email): void {
        ArquivoLock::executar('login_attempts', function () use ($email) {
            $data = $this->all();
            $chave = strtolower(trim($email));

            $tentativas = ($data[$chave]['tentativas'] ?? 0) + 1;

            if ($tentativas >= self::MAX_TENTATIVAS) {
                $data[$chave] = [
                    'tentativas' => 0,
                    'bloqueado_ate' => time() + self::BLOQUEIO_SEGUNDOS,
                ];
            } else {
                $data[$chave]['tentativas'] = $tentativas;
            }

            $this->saveAll($data);
        });
    }

    /** Limpa o histórico de tentativas (chamar após um login bem-sucedido). */
    public function limpar(string $email): void {
        ArquivoLock::executar('login_attempts', function () use ($email) {
            $data = $this->all();
            unset($data[strtolower(trim($email))]);
            $this->saveAll($data);
        });
    }
}
