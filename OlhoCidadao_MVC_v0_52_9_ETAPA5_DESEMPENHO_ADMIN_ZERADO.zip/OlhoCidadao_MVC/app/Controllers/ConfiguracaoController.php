<?php
class ConfiguracaoController extends Controller {
    private const PADRAO = [
        'temaEscuro' => true,
        'idioma' => 'pt-br',
        'fonte' => 'padrao',
        'altoContraste' => false,
        'modoDaltonico' => false,
        'fonteLeitura' => false
    ];

    public function index(): void {
        $id = $this->auth();
        $usuario = (new User)->find($id);
        $ehAdmin = ($usuario['role'] ?? 'cidadao') === 'admin';
        // Config vem da conta (persiste entre navegadores/aparelhos); se o
        // usuário nunca salvou nada ainda, cai no padrão.
        $cfg = !empty($usuario['config']) ? array_merge(self::PADRAO, $usuario['config']) : self::PADRAO;

        $erro=$_SESSION['error']??null;unset($_SESSION['error']);
        $sucesso=$_SESSION['sucesso']??null;unset($_SESSION['sucesso']);
        $segredoPendente=$ehAdmin ? ($_SESSION['totp_pendente']??null) : null;
        $codigosRecuperacao=$ehAdmin ? ($_SESSION['totp_codigos']??null) : null;
        unset($_SESSION['totp_codigos']); // mostrar uma única vez, nunca armazenar em arquivo/sessão persistente
        $this->view('configuracoes/index', compact('usuario', 'cfg', 'ehAdmin', 'erro', 'sucesso', 'segredoPendente', 'codigosRecuperacao'));
    }

    public function save(): void {
        $id = $this->auth();
        $this->csrfCheck(BASE_URL . '/?rota=configuracoes');

        $idiomasValidos = ['pt-br', 'en', 'es'];
        $fontesValidas = ['padrao', 'grande', 'extra-grande'];

        $idioma = $_POST['idioma'] ?? 'pt-br';
        $fonte = $_POST['fonte'] ?? 'padrao';

        $config = [
            'temaEscuro' => isset($_POST['temaEscuro']),
            'idioma' => in_array($idioma, $idiomasValidos, true) ? $idioma : 'pt-br',
            'fonte' => in_array($fonte, $fontesValidas, true) ? $fonte : 'padrao',
            'altoContraste' => isset($_POST['altoContraste']),
            'modoDaltonico' => isset($_POST['modoDaltonico']),
            'fonteLeitura' => isset($_POST['fonteLeitura'])
        ];

        // Salva na conta (não só na sessão) — assim a preferência acompanha
        // o usuário mesmo trocando de navegador ou de aparelho.
        (new User)->update($id, ['config' => $config]);

        $this->redirect(BASE_URL . '/?rota=configuracoes');
    }
    public function iniciar2fa(): void {
        $id=$this->authAdmin();
        $this->csrfCheck(BASE_URL.'/?rota=configuracoes');
        $limite=new RateLimiter('2fa-iniciar', maxTentativas:5, bloqueioSegundos:900);
        if ($limite->bloqueado()>0) {
            $_SESSION['error']='Muitas tentativas. Aguarde 15 minutos.';
            $this->redirect(BASE_URL.'/?rota=configuracoes');
        }
        $limite->registrarTentativa();
        $u=(new User)->find($id);
        if (SegurancaConta::doisFatoresAtivo($u)) {
            $_SESSION['error']='A verificação em duas etapas já está ativa.';
        } elseif (empty($_POST['senha_atual']) || !password_verify((string)$_POST['senha_atual'], $u['senha']??'')) {
            $_SESSION['error']='Informe sua senha atual para configurar o 2FA.';
        } else {
            $limite->limpar();
            $_SESSION['totp_pendente']=['segredo'=>Totp::segredo(),'id'=>$id,'expira'=>time()+600];
            $_SESSION['sucesso']='Cadastre a chave no aplicativo autenticador e confirme o código.';
        }
        $this->redirect(BASE_URL.'/?rota=configuracoes');
    }

    public function ativar2fa(): void {
        $id=$this->authAdmin();
        $this->csrfCheck(BASE_URL.'/?rota=configuracoes');
        $pendente=$_SESSION['totp_pendente']??null;
        if (!is_array($pendente) || ($pendente['id']??0)!==$id || ($pendente['expira']??0)<time()
            || Totp::passoValido((string)($pendente['segredo']??''),trim((string)($_POST['codigo']??'')))===null) {
            $_SESSION['error']='Código inválido ou cadastro expirado. Solicite uma nova chave.';
            $this->redirect(BASE_URL.'/?rota=configuracoes');
        }
        $codigos=SegurancaConta::ativar2fa($id,$pendente['segredo']);
        unset($_SESSION['totp_pendente']);
        if (!$codigos) {
            $_SESSION['error']='Não foi possível ativar o 2FA.';
        } else {
            $_SESSION['auth_epoch']=(int)((new User)->find($id)['auth_epoch']??0);
            $_SESSION['admin_totp_ok']=true;
            $_SESSION['totp_codigos']=$codigos;
            (new LogAuditoria)->registrar($id,(string)((new User)->find($id)['nome']??'Admin'),'Ativou o 2FA administrativo');
            $_SESSION['sucesso']='2FA ativado. Guarde seus códigos de recuperação em lugar seguro.';
        }
        $this->redirect(BASE_URL.'/?rota=configuracoes');
    }

    public function desativar2fa(): void {
        $id=$this->authAdmin();
        $this->csrfCheck(BASE_URL.'/?rota=configuracoes');
        $limite=new RateLimiter('2fa-desativar', maxTentativas:5, bloqueioSegundos:900);
        if ($limite->bloqueado()>0) {
            $_SESSION['error']='Muitas tentativas. Aguarde 15 minutos.';
            $this->redirect(BASE_URL.'/?rota=configuracoes');
        }
        $u=(new User)->find($id);
        if (empty($_POST['senha_atual']) || !password_verify((string)$_POST['senha_atual'],$u['senha']??'')) {
            $limite->registrarTentativa();
            $_SESSION['error']='Senha atual incorreta.';
        } elseif (!SegurancaConta::verificar2fa($id,(string)($_POST['codigo']??''))) {
            $limite->registrarTentativa();
            $_SESSION['error']='Código 2FA inválido ou já utilizado.';
        } elseif (SegurancaConta::desativar2fa($id)) {
            $limite->limpar();
            (new LogAuditoria)->registrar($id,(string)($u['nome']??'Admin'),'Desativou o 2FA administrativo');
            $_SESSION['auth_epoch']=(int)((new User)->find($id)['auth_epoch']??0);
            unset($_SESSION['admin_totp_ok']);
            $_SESSION['sucesso']='Verificação em duas etapas desativada.';
        }
        $this->redirect(BASE_URL.'/?rota=configuracoes');
    }

}
