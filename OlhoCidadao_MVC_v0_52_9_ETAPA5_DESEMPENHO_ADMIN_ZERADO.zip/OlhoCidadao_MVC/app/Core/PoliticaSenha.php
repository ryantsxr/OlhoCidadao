<?php
/** Regra central para TODAS as operações que criam ou alteram senhas. */
class PoliticaSenha {
    public static function erro(string $senha): ?string {
        $tamanho = strlen($senha);
        if ($tamanho < 8 || $tamanho > 72) {
            return 'A senha deve ter entre 8 e 72 caracteres.';
        }
        $normalizada = function_exists('mb_strtolower') ? mb_strtolower(trim($senha), 'UTF-8') : strtolower(trim($senha));
        $comum = preg_replace('/[^a-z0-9]/', '', (function_exists('iconv') ? iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $normalizada) : false) ?: $normalizada) ?? '';
        $fracas = [
            '123456', '1234567', '12345678', '123456789', '1234567890',
            '87654321', 'qwerty', 'qwerty123', 'qwertyuiop', 'senha', 'senha123',
            'senha1234', 'password', 'password123', 'admin123', 'admin1234',
            'administrador', 'iloveyou', 'abc12345', '11111111', '00000000',
            '123123123', '65432100', 'brasil123', 'letmein123',
        ];
        if (in_array($comum, $fracas, true)
            || preg_match('/^(.)\1{7,}$/us', $normalizada)
            || preg_match('/^(?:0123456789|9876543210|abcdefghijklmnopqrstuvwxyz|qwertyuiop)$/', $comum)) {
            return 'Essa senha é muito comum. Escolha uma senha menos previsível.';
        }
        return null;
    }
}
