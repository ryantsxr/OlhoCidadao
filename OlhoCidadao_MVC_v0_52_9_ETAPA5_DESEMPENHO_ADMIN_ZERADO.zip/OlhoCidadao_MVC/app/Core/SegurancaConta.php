<?php
/** Alterações críticas de autenticação: sempre com lock de users.json. */
final class SegurancaConta {
    private static function modificar(int $id, callable $acao): bool {
        return ArquivoLock::executar('users', static function () use ($id, $acao): bool {
            $file=__DIR__.'/../../storage/users.json';
            $users=LeituraJson::array($file);
            foreach ($users as &$u) {
                if ((int)($u['id']??0) !== $id) continue;
                $alterou=$acao($u);
                if ($alterou) GravacaoSegura::json($file, $users);
                return $alterou;
            }
            return false;
        });
    }
    public static function verificacaoHabilitada(): bool {
        return defined('VERIFICACAO_EMAIL_ATIVA') && VERIFICACAO_EMAIL_ATIVA
            && Mailer::smtpConfigurado() && trim((string)APP_URL) !== ''
            && str_starts_with((string)APP_URL, 'https://');
    }
    public static function emailVerificado(array $u): bool {
        return ($u['role']??'cidadao') === 'admin' || ($u['email_verificado']??true) === true;
    }
    public static function emitirTokenEmail(int $id): ?string {
        $token=bin2hex(random_bytes(32));
        $salvou=self::modificar($id, static function (&$u) use ($token): bool {
            if (($u['role']??'cidadao')==='admin' || ($u['email_verificado']??true)===true) return false;
            $u['email_token_hash']=hash('sha256', $token);
            $u['email_token_expira']=time()+86400;
            return true;
        });
        return $salvou ? $token : null;
    }
    public static function confirmarEmail(string $token): bool {
        if (!preg_match('/^[a-f0-9]{64}$/D', $token)) return false;
        return ArquivoLock::executar('users', static function () use ($token): bool {
            $file=__DIR__.'/../../storage/users.json';
            $users=LeituraJson::array($file);
            foreach ($users as &$u) {
                if (!hash_equals((string)($u['email_token_hash']??''), hash('sha256',$token))) continue;
                if ((int)($u['email_token_expira']??0) < time()) return false;
                $u['email_verificado']=true;
                unset($u['email_token_hash'], $u['email_token_expira']);
                GravacaoSegura::json($file,$users);
                return true;
            }
            return false;
        });
    }
    public static function enviarVerificacao(array $u): bool {
        if (!self::verificacaoHabilitada()) return false;
        $token=self::emitirTokenEmail((int)$u['id']);
        if (!$token) return false;
        $url=Mailer::url('/?rota=verificar-email&token='.$token);
        return Mailer::enviar((string)$u['email'], (string)$u['nome'], 'Confirme seu e-mail - Olho Cidadão',
            "Confirme o seu cadastro acessando o link (válido por 24 horas):\n{$url}\nSe não foi você, ignore.",
            Mailer::modelo('Confirmar e-mail', 'Olá!', ['Para utilizar sua conta, confirme o seu endereço de e-mail. O link expira em 24 horas.'], 'Confirmar meu e-mail', $url));
    }
    public static function doisFatoresAtivo(array $u): bool {
        return ($u['totp_ativo']??false)===true;
    }
    /** Somente o dono da conta, após validar senha e TOTP, ativa a proteção. */
    public static function ativar2fa(int $id, string $segredo): array {
        $codigos=[];
        for($i=0;$i<8;$i++) $codigos[]=strtoupper(bin2hex(random_bytes(5)));
        $cifrado=Totp::cifrar($segredo);
        $hashes=array_map(static fn($c)=>hash('sha256',$c), $codigos);
        $ok=self::modificar($id, static function (&$u) use ($cifrado,$hashes): bool {
            if (($u['role']??'cidadao') !== 'admin' || self::doisFatoresAtivo($u)) return false;
            $u['totp_segredo']=$cifrado;
            $u['totp_ativo']=true;
            $u['totp_backups']=$hashes;
            $u['totp_ultimo_passo']=-1;
            $u['auth_epoch']=(int)($u['auth_epoch']??0)+1;
            return true;
        });
        return $ok ? $codigos : [];
    }
    public static function verificar2fa(int $id, string $codigo): bool {
        $codigo=strtoupper(trim(str_replace([' ','-'],'',$codigo)));
        return self::modificar($id, static function (&$u) use ($codigo): bool {
            if (!self::doisFatoresAtivo($u)) return false;
            if (preg_match('/^\d{6}$/D',$codigo)) {
                $segredo=Totp::decifrar((string)$u['totp_segredo']);
                $passo=Totp::passoValido($segredo,$codigo,(int)($u['totp_ultimo_passo']??-1));
                if ($passo===null) return false;
                $u['totp_ultimo_passo']=$passo;
                return true;
            }
            // Códigos de recuperação: hash e consumo atômico; cada um serve uma única vez.
            if (!preg_match('/^[A-F0-9]{10}$/D',$codigo)) return false;
            foreach (($u['totp_backups']??[]) as $i=>$hash) {
                if (!hash_equals((string)$hash,hash('sha256',$codigo))) continue;
                unset($u['totp_backups'][$i]);
                $u['totp_backups']=array_values($u['totp_backups']);
                return true;
            }
            return false;
        });
    }
    public static function desativar2fa(int $id): bool {
        return self::modificar($id, static function (&$u): bool {
            if (!self::doisFatoresAtivo($u)) return false;
            unset($u['totp_segredo'],$u['totp_ativo'],$u['totp_backups'],$u['totp_ultimo_passo']);
            $u['auth_epoch']=(int)($u['auth_epoch']??0)+1;
            return true;
        });
    }
}
