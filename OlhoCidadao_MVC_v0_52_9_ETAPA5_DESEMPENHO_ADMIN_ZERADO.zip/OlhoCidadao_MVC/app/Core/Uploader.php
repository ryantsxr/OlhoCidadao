<?php
/**
 * Upload de imagem compartilhado entre a foto da denúncia (cidadão) e a foto
 * de comprovação de resolução (admin) — mesma validação nos dois casos
 * (tipo real do arquivo via finfo, tamanho máximo, nome aleatório), pra não
 * duplicar (e arriscar dessincronizar) a parte sensível dessa lógica.
 */
class Uploader {
    /** Apaga apenas anexos privados gerados pelo próprio upload. */
    public static function apagarUploadPrivado(string $url): void {
        parse_str((string)parse_url($url, PHP_URL_QUERY), $parametros);
        $nome = (string)($parametros['arquivo'] ?? '');
        if (str_contains($url, '?rota=anexo&') && preg_match('/^[a-zA-Z0-9_-]+\.(?:jpg|png|webp)$/D', $nome)) {
            @unlink(__DIR__ . '/../../storage/uploads/' . $nome);
        }
    }

    private const TAMANHO_MAXIMO = 5 * 1024 * 1024; // 5 MB

    private const MIME_PARA_EXTENSAO = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];

    /**
     * Valida e salva a imagem enviada em $_FILES[$campo], se houver alguma.
     *
     * Retorna:
     *   - a URL autenticada (?rota=anexo&arquivo=...) em caso de sucesso;
     *   - string vazia se o campo simplesmente não foi enviado (opcional);
     * Lança \RuntimeException com uma mensagem amigável se veio algo, mas é
     * inválido (tipo não suportado, tamanho excedido, falha no upload).
     */
    public static function salvarImagemEnviada(string $campo, string $prefixoNome): string {
        if (
            !isset($_FILES[$campo]) ||
            !is_array($_FILES[$campo]) ||
            ($_FILES[$campo]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE
        ) {
            return '';
        }

        if ($_FILES[$campo]['error'] !== UPLOAD_ERR_OK) {
            throw new \RuntimeException('Falha ao enviar a imagem. Tente novamente.');
        }

        if ((int) $_FILES[$campo]['size'] > self::TAMANHO_MAXIMO) {
            throw new \RuntimeException('A imagem deve ter no máximo 5 MB.');
        }

        $tmp = $_FILES[$campo]['tmp_name'];
        if (!is_string($tmp) || !is_uploaded_file($tmp)) {
            throw new \RuntimeException('O envio da imagem não é válido. Tente novamente.');
        }
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($tmp);
        // getimagesize não precisa da extensão GD: verifica também se há uma
        // imagem real, reduzindo o risco de arquivos disfarçados.
        $dimensoes = @getimagesize($tmp);
        if (!isset(self::MIME_PARA_EXTENSAO[$mime]) ||
            $dimensoes === false || ($dimensoes['mime'] ?? '') !== $mime) {
            throw new \RuntimeException('Formato de imagem não suportado. Envie JPG, PNG ou WEBP.');
        }

        $uploadDir = __DIR__ . '/../../storage/uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $nome = $prefixoNome . '_' . bin2hex(random_bytes(8)) . '.' . self::MIME_PARA_EXTENSAO[$mime];
        $destino = $uploadDir . $nome;

        // Se GD estiver disponível, remove os metadados e corrige a rotação.
        // Sem GD, conserva o funcionamento anterior, mas mantém a imagem
        // ORIGINAL (inclusive metadados EXIF). Ela fica em storage/uploads e
        // só pode ser lida pela rota autenticada e autorizada de anexos.
        if (function_exists('imagecreatefromstring')) {
            if (!self::regravarSemMetadados($tmp, $destino, $mime)) {
                throw new \RuntimeException('Não foi possível ler essa imagem. Tente outra foto (JPG, PNG ou WEBP).');
            }
        } elseif (!move_uploaded_file($tmp, $destino)) {
            throw new \RuntimeException('Não foi possível salvar a imagem. Verifique as permissões da hospedagem.');
        }

        return BASE_URL . '/?rota=anexo&arquivo=' . rawurlencode($nome);
    }

    /**
     * Abre a imagem com o GD e salva de novo no destino, sem os metadados.
     * Corrige a rotação das fotos de celular (que ficam só no EXIF) antes de apagá-lo.
     * Retorna false se o arquivo não for uma imagem de verdade.
     */
    private static function regravarSemMetadados(string $origem, string $destino, string $mime): bool {
        $conteudo = @file_get_contents($origem);
        $imagem = $conteudo !== false ? @imagecreatefromstring($conteudo) : false;
        if ($imagem === false) {
            return false;
        }

        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $exif = @exif_read_data($origem);
            $giro = [3 => 180, 6 => -90, 8 => 90][$exif['Orientation'] ?? 1] ?? 0;
            if ($giro !== 0) {
                $girada = imagerotate($imagem, $giro, 0);
                if ($girada !== false) {
                    $imagem = $girada;
                }
            }
        }

        if ($mime === 'image/png' || $mime === 'image/webp') {
            imagealphablending($imagem, false);
            imagesavealpha($imagem, true); // mantém a transparência
        }

        if ($mime === 'image/jpeg') {
            $ok = imagejpeg($imagem, $destino, 88);
        } elseif ($mime === 'image/png') {
            $ok = imagepng($imagem, $destino);
        } else {
            $ok = function_exists('imagewebp') ? imagewebp($imagem, $destino, 88) : false;
        }

        imagedestroy($imagem);
        return $ok;
    }
}
