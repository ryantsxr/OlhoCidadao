<?php
/**
 * Trava simples para os arquivos JSON.
 *
 * Problema que resolve: os Models leem o JSON, mudam alguma coisa e gravam de
 * volta. Se duas pessoas fazem isso no mesmo instante, uma das alterações pode
 * se perder. Aqui, quem chega primeiro "segura a chave" e o outro espera.
 *
 * Uso:
 *   return ArquivoLock::executar('denuncias', function () {
 *       // ler, alterar e gravar aqui dentro
 *   });
 *
 * Importante: não chame executar() com o mesmo nome dentro de outro executar()
 * (ficaria esperando por ele mesmo).
 */
class ArquivoLock {
    public static function executar(string $nome, callable $acao) {
        $nome = preg_replace('/[^a-zA-Z0-9_-]/', '', $nome);
        $dir = __DIR__ . '/../../storage/';
        $caminho = $dir . '.lock_' . $nome;

        $arquivo = @fopen($caminho, 'c');
        if ($arquivo === false) {
            // Sem uma trava válida, falhar em segurança para evitar perder dados concorrentes.
            throw new RuntimeException('Diretório storage sem permissão de gravação (lock).');
        }

        if (!flock($arquivo, LOCK_EX)) {
            fclose($arquivo);
            throw new RuntimeException('Não foi possível bloquear o arquivo de dados.');
        }
        try {
            return $acao();
        } finally {
            flock($arquivo, LOCK_UN);
            fclose($arquivo);
        }
    }
}
