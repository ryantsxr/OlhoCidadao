<?php
/** Backup diário, por acesso web ou por CLI. Não faz backup das chaves de cifragem. */
class BackupDiario {
    public static function executar(): bool {
        $storage = __DIR__ . '/../../storage';
        $raiz = $storage . '/backups';
        if (!is_dir($raiz) && !mkdir($raiz, 0700, true) && !is_dir($raiz)) {
            throw new RuntimeException('Sem permissão para criar storage/backups.');
        }
        $dia = date('Y-m-d');
        $destino = $raiz . '/' . $dia;
        // Se o backup de hoje já terminou, não abre o arquivo de lock em cada visita.
        // A segunda verificação, dentro do lock, continua evitando corridas simultâneas.
        if (is_file($destino . '/manifesto.json')) return false;
        return ArquivoLock::executar('backup-diario', static function () use ($storage, $raiz, $destino, $dia): bool {
            if (is_file($destino . '/manifesto.json')) return false;
            if (!is_dir($destino) && !mkdir($destino, 0700, true) && !is_dir($destino)) {
                throw new RuntimeException('Sem permissão para criar pasta de backup diário.');
            }
            $arquivos = glob($storage . '/*.json') ?: [];
            $manifesto = ['data' => $dia, 'criado_em' => date(DATE_ATOM), 'arquivos' => []];
            foreach ($arquivos as $arquivo) {
                if (!is_file($arquivo)) continue;
                $nome = basename($arquivo);
                $in = @fopen($arquivo, 'rb');
                if ($in === false) throw new RuntimeException('Falha ao abrir JSON de backup: ' . $nome);
                try {
                    flock($in, LOCK_SH);
                    $conteudo = stream_get_contents($in);
                    flock($in, LOCK_UN);
                } finally {
                    fclose($in);
                }
                if ($conteudo === false) throw new RuntimeException('Falha ao ler JSON: ' . $nome);
                // Snapshot só é marcado completo depois de todos os JSON gravados.
                $temp = $destino . '/.' . $nome . '.tmp';
                if (file_put_contents($temp, $conteudo, LOCK_EX) === false || !rename($temp, $destino . '/' . $nome)) {
                    throw new RuntimeException('Falha ao salvar backup: ' . $nome);
                }
                @chmod($destino . '/' . $nome, 0600);
                $manifesto['arquivos'][$nome] = hash('sha256', $conteudo);
            }
            // Backup das imagens recebidas junto com o JSON: sem isso uma restauração
            // recuperaria relatos, mas deixaria suas fotos quebradas.
            $uploads = $storage . '/uploads';
            if (is_dir($uploads)) {
                $copiaDir = $destino . '/uploads';
                if (!is_dir($copiaDir) && !mkdir($copiaDir, 0700, true)) {
                    throw new RuntimeException('Falha ao criar backup de fotos.');
                }
                foreach (glob($uploads . '/*') ?: [] as $original) {
                    if (!is_file($original) || !preg_match('/^[a-zA-Z0-9_-]+\.(jpg|png|webp)$/', basename($original))) continue;
                    $nome = basename($original);
                    if (!copy($original, $copiaDir . '/' . $nome)) throw new RuntimeException('Falha ao copiar anexo: ' . $nome);
                    @chmod($copiaDir . '/' . $nome, 0600);
                    $manifesto['arquivos']['uploads/' . $nome] = hash_file('sha256', $original);
                }
            }
            if (!$manifesto['arquivos']) throw new RuntimeException('Não há arquivos JSON para fazer backup.');
            $json = json_encode($manifesto, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            if (file_put_contents($destino . '/manifesto.json', $json, LOCK_EX) === false) {
                throw new RuntimeException('Falha ao concluir manifesto do backup.');
            }
            @chmod($destino . '/manifesto.json', 0600);
            // Retenção por 30 dias; dados apagados podem persistir em backups até então.
            foreach (glob($raiz . '/????-??-??') ?: [] as $pasta) {
                if (!is_dir($pasta) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', basename($pasta))) continue;
                if (strtotime(basename($pasta) . ' 00:00:00') >= strtotime('-30 days midnight')) continue;
                foreach (glob($pasta . '/uploads/*') ?: [] as $item) if (is_file($item)) @unlink($item);
                if (is_dir($pasta . '/uploads')) @rmdir($pasta . '/uploads');
                foreach (glob($pasta . '/*') ?: [] as $item) if (is_file($item)) @unlink($item);
                @rmdir($pasta);
            }
            return true;
        });
    }
}
