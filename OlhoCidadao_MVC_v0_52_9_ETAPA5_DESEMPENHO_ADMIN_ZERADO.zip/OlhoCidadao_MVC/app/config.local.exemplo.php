<?php
// Copie este arquivo para app/config.local.php e preencha com os seus dados.
// O config.local.php é privado: não envie para o GitHub e não compartilhe a senha.

// Endereço do site (sem barra no final). Obrigatório quando o sistema estiver
// hospedado na internet — é ele que vai nos links dos e-mails.
// No seu computador (localhost) pode deixar vazio.
define('APP_URL', '');                       // ex.: 'https://meusite.com.br/OlhoCidadao/public'

// Gmail
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
define('SMTP_USER', 'seuemail@gmail.com');   // o Gmail que vai ENVIAR os e-mails
define('SMTP_PASS', 'xxxx xxxx xxxx xxxx');  // "Senha de app" de 16 letras (NÃO é a senha do Gmail)
define('SMTP_FROM_NOME', 'Olho Cidadão');

// Só se aparecer erro de certificado (comum no XAMPP/Windows), e só no seu computador:
// define('SMTP_VERIFY_SSL', false);

// -------------------------------------------------------------------------
// Assistente Olhinho com IA (opcional). Deixe comentado para usar só as
// respostas prontas (funciona sem internet e sem custo).
// -------------------------------------------------------------------------
// Claude (Anthropic) — crie a chave em https://console.anthropic.com
// define('ASSISTENTE_IA_PROVEDOR', 'anthropic');
// define('ASSISTENTE_IA_CHAVE', 'sk-ant-...');
//
// OpenAI (ou outro serviço compatível, informando a URL):
// define('ASSISTENTE_IA_PROVEDOR', 'openai');
// define('ASSISTENTE_IA_CHAVE', 'sk-...');
// define('ASSISTENTE_IA_MODELO', 'gpt-4o-mini');
// define('ASSISTENTE_IA_URL', 'https://api.openai.com/v1/chat/completions');
//
// Só se aparecer erro de certificado no XAMPP, e só no seu computador:
// define('ASSISTENTE_IA_VERIFY_SSL', false);

// Privacidade e sessão (opcional):
// define('SESSION_IDLE_SECONDS', 1800);  // 30 minutos
// define('LGPD_CONTATO', 'contato@exemplo.com'); // endereço real da equipe

// Após verificar SMTP e APP_URL HTTPS:
// define('VERIFICACAO_EMAIL_ATIVA', true);
