<?php
/**
 * Widget oficial do VLibras (Governo Federal) — tradução do conteúdo do site para Libras.
 * Incluído no final de cada página, logo antes do </body>.
 * O widget usa os servidores públicos do VLibras (vlibras.gov.br), então não precisa
 * hospedar a translate-api nem RabbitMQ/MongoDB.
 */
?>
<div vw class="enabled">
    <div vw-access-button class="active"></div>
    <div vw-plugin-wrapper>
        <div class="vw-plugin-top-wrapper"></div>
    </div>
</div>
<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>new window.VLibras.Widget('https://vlibras.gov.br/app');</script>
